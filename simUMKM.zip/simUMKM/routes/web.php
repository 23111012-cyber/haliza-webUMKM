<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// New route for /goal returning the goal view
Route::get('/goal', [\App\Http\Controllers\GoalController::class, 'index']);
