/**
 * PREMIUM DIGITAL AGENCY & WEB DEVELOPMENT LANDING PAGE JS
 * Custom interactions, active states, sticky nav, form submission triggers
 */

document.addEventListener('DOMContentLoaded', () => {
    
    // 1. Sticky Transparent-to-Solid Navbar on Scroll
    const navbar = document.querySelector('.navbar');
    
    const handleNavbarScroll = () => {
        if (window.scrollY > 50) {
            navbar.classList.add('navbar-scrolled');
        } else {
            navbar.classList.remove('navbar-scrolled');
        }
    };
    
    // Initial check on load
    handleNavbarScroll();
    window.addEventListener('scroll', handleNavbarScroll);
    
    // 2. Active States for Scroll Spy (Bootstrap 5 ScrollSpy equivalent)
    const sections = document.querySelectorAll('section, header');
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    
    const handleScrollSpy = () => {
        let currentSectionId = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 120; // offset navbar height
            const sectionHeight = section.offsetHeight;
            
            if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
                currentSectionId = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${currentSectionId}` || 
                (currentSectionId === 'hero' && link.getAttribute('href') === '#home')) {
                link.classList.add('active');
            }
        });
    };
    
    window.addEventListener('scroll', handleScrollSpy);
    
    // 3. Smooth Anchor Link Scrolling
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    
    anchorLinks.forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                e.preventDefault();
                
                // Close mobile navbar menu if open
                const navbarToggler = document.querySelector('.navbar-toggler');
                const navbarCollapse = document.querySelector('.navbar-collapse');
                if (navbarCollapse.classList.contains('show')) {
                    navbarToggler.click();
                }
                
                const yOffset = -80; // offset for the navbar
                const y = targetElement.getBoundingClientRect().top + window.pageYOffset + yOffset;
                
                window.scrollTo({
                    top: y,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // 4. Contact Form Simulated Submit & Premium Alert Feedback
    const contactForm = document.getElementById('premiumContactForm');
    const formResponse = document.getElementById('formResponse');
    
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Get values
            const name = document.getElementById('inputName').value.trim();
            const email = document.getElementById('inputEmail').value.trim();
            const phone = document.getElementById('inputPhone').value.trim();
            const service = document.getElementById('selectService').value;
            const message = document.getElementById('textareaMessage').value.trim();
            
            // Simple validation check
            if (!name || !email || !message) {
                showFeedback('Silakan lengkapi formulir wajib (Nama, Email, dan Pesan).', 'danger');
                return;
            }
            
            // Simulation submission transition
            const submitBtn = contactForm.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Mengirim...';
            
            setTimeout(() => {
                // Done loading
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
                
                // Show beautiful Bootstrap Alert success
                showFeedback(`<strong>Terima kasih, ${name}!</strong> Pesan Anda berhasil dikirim. Kami akan segera menghubungi Anda melalui email atau WhatsApp.`, 'success');
                
                // Reset form
                contactForm.reset();
            }, 1500);
        });
    }
    
    const showFeedback = (message, type) => {
        if (formResponse) {
            formResponse.style.display = 'block';
            formResponse.className = `alert alert-${type} alert-dismissible fade show`;
            formResponse.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            `;
            
            // Scroll slightly to the response
            formResponse.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    };
});
