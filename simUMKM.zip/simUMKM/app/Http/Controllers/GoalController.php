<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GoalController extends Controller
{
    /**
     * Show a simple page for the /goal route.
     */
    public function index()
    {
        return view('goal');
    }
}
