<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <!-- SEO Meta Tags -->
    <title>Haliza UMKM Web - Jasa Pembuatan Website Premium & Modern Terpercaya</title>
    <meta name="description" content="Jasa pembuatan website profesional, clean, aesthetic, dan responsive menggunakan Bootstrap 5. Spesialis landing page, company profile, dan e-commerce dengan sentuhan desain premium.">
    <meta name="keywords" content="jasa website, pembuatan website premium, website aesthetic, digital agency, landing page bootstrap 5, website responsive, simUMKM">
    <meta name="author" content="Haliza UMKM Web Agency">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url('/') }}">
    <meta property="og:title" content="Haliza UMKM Web - Jasa Pembuatan Website Premium & Modern">
    <meta property="og:description" content="Jadikan bisnis Anda naik kelas dengan website berdesain profesional, clean, aesthetic, dan fully responsive.">
    <meta property="og:image" content="{{ asset('assets/images/hero-banner.png') }}">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="{{ url('/') }}">
    <meta property="twitter:title" content="Haliza UMKM Web - Jasa Pembuatan Website Premium & Modern">
    <meta property="twitter:description" content="Jadikan bisnis Anda naik kelas dengan website berdesain profesional, clean, aesthetic, dan fully responsive.">
    <meta property="twitter:image" content="{{ asset('assets/images/hero-banner.png') }}">

    <!-- Favicon -->
    <link rel="shortcut icon" href="{{ asset('favicon.ico') }}" type="image/x-icon">

    <!-- Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    
    <!-- Animate On Scroll (AOS) CSS -->
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    
    <!-- Custom Style Sheet -->
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="100">

    <!-- Navbar Section -->
    <nav class="navbar navbar-expand-lg fixed-top" id="mainNavbar">
        <div class="container">
            <a class="navbar-brand" href="#hero" id="navBrandLogo">
                <i class="bi bi-hexagon-fill text-pink-primary me-2"></i>Haliza UMKM <span>Web</span>
            </a>
            <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation" id="navbarTogglerBtn">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" href="#hero" id="navLinkHome">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#keunggulan" id="navLinkKeunggulan">Keunggulan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#paket" id="navLinkPaket">Paket Harga</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#portofolio" id="navLinkPortofolio">Katalog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#kontak" id="navLinkKontak">Kontak</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center">
                    <a href="#paket" class="btn btn-premium-pink d-none d-lg-inline-block" id="navCtaBtn">Mulai Project</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <header class="hero-section" id="hero">
        <!-- Floating Blob Background -->
        <div class="hero-blob hero-blob-1"></div>
        <div class="hero-blob hero-blob-2"></div>
        
        <div class="container">
            <div class="row align-items-center min-vh-75">
                <!-- Left Text Hero -->
                <div class="col-lg-6 hero-content text-start" data-aos="fade-right" data-aos-duration="1000">
                    <span class="badge bg-pink-light text-pink-primary px-3 py-2 rounded-pill fw-semibold mb-3">
                        <i class="bi bi-stars me-2"></i>Jasa Pembuatan Website
                    </span>
                    <h1 class="display-4 fw-extrabold mb-3" style="line-height: 1.2;">
                        Website <span class="text-gradient">Premium & Modern</span> untuk Usaha Anda Naik Kelas
                    </h1>
                    <p class="lead text-muted mb-4 fs-6">
                        Haliza UMKM Web menghadirkan layanan pembuatan website profesional, clean, aesthetic, dan fully responsive menggunakan Bootstrap 5 terbaru. Tingkatkan kredibilitas brand Anda, datangkan lebih banyak pembeli, dan kembangkan bisnis tanpa batas.
                    </p>
                    <div class="d-flex flex-wrap gap-3">
                        <a href="#paket" class="btn btn-premium-pink btn-lg px-4" id="heroCtaPrimary">
                            <i class="bi bi-wallet2 me-2"></i>Lihat Paket Jasa
                        </a>
                        <a href="#kontak" class="btn btn-premium-outline btn-lg px-4" id="heroCtaSecondary">
                            <i class="bi bi-chat-text me-2"></i>Konsultasi Gratis
                        </a>
                    </div>
                    
                    <!-- Agency Trust Elements -->
                    <div class="row mt-5 pt-3 border-top border-pink-light d-none d-sm-flex">
                        <div class="col-4">
                            <h4 class="fw-bold text-pink-primary mb-0">100%</h4>
                            <p class="small text-muted mb-0">Responsive UI</p>
                        </div>
                        <div class="col-4">
                            <h4 class="fw-bold text-pink-primary mb-0">A++</h4>
                            <p class="small text-muted mb-0">Speed & SEO</p>
                        </div>
                        <div class="col-4">
                            <h4 class="fw-bold text-pink-primary mb-0">24/7</h4>
                            <p class="small text-muted mb-0">Full Support</p>
                        </div>
                    </div>
                </div>
                <!-- Right Banner Mockup -->
                <div class="col-lg-6 hero-image-wrapper text-center mt-5 mt-lg-0" data-aos="fade-left" data-aos-duration="1000">
                    <img src="{{ asset('assets/images/hero-banner.png') }}" alt="Premium Web Design Illustration" class="img-fluid hero-banner-img" style="max-height: 480px;">
                </div>
            </div>
        </div>
    </header>

    <!-- Keunggulan Section -->
    <section class="py-5 bg-white" id="keunggulan">
        <div class="container py-5">
            <!-- Section Title -->
            <div class="row justify-content-center text-center mb-5">
                <div class="col-lg-7" data-aos="fade-up" data-aos-duration="800">
                    <span class="section-subtitle">Mengapa Memilih Kami?</span>
                    <h2 class="section-title">Nikmati Kemudahan Membuat Website Premium</h2>
                    <p class="text-muted">Kami mendesain setiap website dari awal dengan dedikasi penuh pada keindahan detail, performa tinggi, dan konversi optimal.</p>
                </div>
            </div>
            
            <!-- Cards Grid -->
            <div class="row g-4 mt-2">
                <!-- Advantage 1 -->
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-duration="800" data-aos-delay="100">
                    <div class="feature-card">
                        <div class="feature-card-content">
                            <div class="feature-icon-wrapper">
                                <i class="bi bi-palette-fill"></i>
                            </div>
                            <h4 class="h5 fw-bold mb-3">Premium & Aesthetic</h4>
                            <p class="text-muted small mb-0">Kombinasi palet warna modern, tipografi memukau, dan layout clean yang dirancang untuk memukau audiens Anda.</p>
                        </div>
                    </div>
                </div>
                <!-- Advantage 2 -->
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-duration="800" data-aos-delay="200">
                    <div class="feature-card">
                        <div class="feature-card-content">
                            <div class="feature-icon-wrapper">
                                <i class="bi bi-phone-fill"></i>
                            </div>
                            <h4 class="h5 fw-bold mb-3">Responsive Layout</h4>
                            <p class="text-muted small mb-0">Tampilan website yang presisi dan sempurna diakses melalui layar desktop, tablet, maupun layar smartphone.</p>
                        </div>
                    </div>
                </div>
                <!-- Advantage 3 -->
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-duration="800" data-aos-delay="300">
                    <div class="feature-card">
                        <div class="feature-card-content">
                            <div class="feature-icon-wrapper">
                                <i class="bi bi-speedometer2"></i>
                            </div>
                            <h4 class="h5 fw-bold mb-3">SEO & Speed Ready</h4>
                            <p class="text-muted small mb-0">Kode yang rapi dan optimasi gambar tingkat lanjut membuat website memuat sangat cepat serta disukai Google.</p>
                        </div>
                    </div>
                </div>
                <!-- Advantage 4 -->
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-duration="800" data-aos-delay="400">
                    <div class="feature-card">
                        <div class="feature-card-content">
                            <div class="feature-icon-wrapper">
                                <i class="bi bi-chat-heart-fill"></i>
                            </div>
                            <h4 class="h5 fw-bold mb-3">Dukungan 24/7</h4>
                            <p class="text-muted small mb-0">Tim teknis handal yang siap mendampingi, memberikan tutorial, dan memandu pembaruan website kapan saja.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Paket Harga Section -->
    <section class="py-5 bg-soft-pink" id="paket">
        <div class="container py-5">
            <!-- Section Title -->
            <div class="row justify-content-center text-center mb-5">
                <div class="col-lg-7" data-aos="fade-up" data-aos-duration="800">
                    <span class="section-subtitle">Investasi Terbaik</span>
                    <h2 class="section-title">Pilih Paket Sesuai Kebutuhan Bisnis Anda</h2>
                    <p class="text-muted">Biaya transparan, pengerjaan cepat, hasil memuaskan dan bergaransi. Tidak ada biaya tersembunyi!</p>
                </div>
            </div>
            
            <!-- Cards Grid -->
            <div class="row g-4 align-items-stretch mt-2">
                <!-- Package 1: Basic -->
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-duration="800" data-aos-delay="100">
                    <div class="pricing-card">
                        <span class="badge bg-pink-light text-pink-primary px-3 py-2 rounded-pill fw-semibold mb-3">BASIC</span>
                        <h3 class="fw-bold mb-2 h4">Landing Page Sederhana</h3>
                        <p class="text-muted small" style="min-height: 48px;">Solusi efisien untuk profil pribadi, portofolio digital, atau promosi satu produk.</p>
                        
                        <div class="price-tag mb-4" style="font-size: 28px; font-weight: 800; color: var(--dark-neutral);">
                            Rp 350.000
                        </div>
                        
                        <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20pesan%20*Paket%20Basic%20(Landing%20Page%20Sederhana)*%20seharga%20Rp%20350.000" target="_blank" class="btn btn-premium-outline w-100 py-3 mb-4" id="orderBasicBtn">
                            <i class="bi bi-whatsapp me-2"></i>Pesan Sekarang
                        </a>
                        
                        <hr class="my-4 border-pink-light">
                        
                        <ul class="price-features">
                            <li><i class="bi bi-check-circle-fill"></i> 1 Halaman Utama</li>
                            <li><i class="bi bi-check-circle-fill"></i> Desain Responsive</li>
                            <li><i class="bi bi-check-circle-fill"></i> Tombol WhatsApp</li>
                            <li><i class="bi bi-check-circle-fill"></i> Form Kontak Aktif</li>
                            <li class="disabled"><i class="bi bi-x-circle-fill"></i> Domain & Hosting gratis</li>
                            <li class="disabled"><i class="bi bi-x-circle-fill"></i> Optimasi SEO dasar</li>
                        </ul>
                    </div>
                </div>
                
                <!-- Package 2: Standard -->
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-duration="800" data-aos-delay="200">
                    <div class="pricing-card">
                        <span class="badge bg-pink-light text-pink-primary px-3 py-2 rounded-pill fw-semibold mb-3">STANDARD</span>
                        <h3 class="fw-bold mb-2 h4">Landing Page + Katalog</h3>
                        <p class="text-muted small" style="min-height: 48px;">Sempurna untuk menampilkan variasi produk UMKM dengan desain profesional.</p>
                        
                        <div class="price-tag mb-4" style="font-size: 28px; font-weight: 800; color: var(--dark-neutral);">
                            Rp 750.000
                        </div>
                        
                        <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20pesan%20*Paket%20Standard%20(Landing%20Page%20%2B%20Katalog%20Produk)*%20seharga%20Rp%20750.000" target="_blank" class="btn btn-premium-outline w-100 py-3 mb-4" id="orderStandardBtn">
                            <i class="bi bi-whatsapp me-2"></i>Pesan Sekarang
                        </a>
                        
                        <hr class="my-4 border-pink-light">
                        
                        <ul class="price-features">
                            <li><i class="bi bi-check-circle-fill"></i> Landing Page Katalog</li>
                            <li><i class="bi bi-check-circle-fill"></i> Desain Premium</li>
                            <li><i class="bi bi-check-circle-fill"></i> Optimasi SEO Dasar</li>
                            <li><i class="bi bi-check-circle-fill"></i> Integrasi WhatsApp</li>
                            <li><i class="bi bi-check-circle-fill"></i> Form Kontak Aktif</li>
                            <li class="disabled"><i class="bi bi-x-circle-fill"></i> Free Domain .com</li>
                        </ul>
                    </div>
                </div>
                
                <!-- Package 3: Premium (Featured) -->
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-duration="800" data-aos-delay="300">
                    <div class="pricing-card featured">
                        <div class="featured-badge">Paling Populer</div>
                        <span class="badge bg-pink-primary text-white px-3 py-2 rounded-pill fw-semibold mb-3">PREMIUM</span>
                        <h3 class="fw-bold mb-2 h4">Website Multi Halaman</h3>
                        <p class="text-muted small" style="min-height: 48px;">Paket terlengkap untuk Company Profile, instansi, dan kredibilitas maksimal.</p>
                        
                        <div class="price-tag mb-4" style="font-size: 28px; font-weight: 800; color: var(--pink-primary);">
                            Rp 1.500.000
                        </div>
                        
                        <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20pesan%20*Paket%20Premium%20(Website%20Lengkap%20Multi%20Halaman)*%20seharga%20Rp%201.500.000" target="_blank" class="btn btn-premium-pink w-100 py-3 mb-4" id="orderPremiumBtn">
                            <i class="bi bi-whatsapp me-2"></i>Pesan Sekarang
                        </a>
                        
                        <hr class="my-4 border-pink-light">
                        
                        <ul class="price-features">
                            <li><i class="bi bi-check-circle-fill"></i> Website Multi Halaman</li>
                            <li><i class="bi bi-check-circle-fill"></i> Domain .com/.id (1 Thn)</li>
                            <li><i class="bi bi-check-circle-fill"></i> Hosting Cepat (1 Thn)</li>
                            <li><i class="bi bi-check-circle-fill"></i> Optimasi SEO Dasar</li>
                            <li><i class="bi bi-check-circle-fill"></i> Form Pemesanan Aktif</li>
                            <li><i class="bi bi-check-circle-fill"></i> Garansi & Maintenance</li>
                        </ul>
                    </div>
                </div>
                
                <!-- Package 4: Business -->
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-duration="800" data-aos-delay="400">
                    <div class="pricing-card">
                        <span class="badge bg-pink-light text-pink-primary px-3 py-2 rounded-pill fw-semibold mb-3">BUSINESS</span>
                        <h3 class="fw-bold mb-2 h4">Full Custom Website</h3>
                        <p class="text-muted small" style="min-height: 48px;">Solusi kustom penuh dengan fitur khusus, performa tinggi, dan support prioritas.</p>
                        
                        <div class="price-tag mb-4" style="font-size: 28px; font-weight: 800; color: var(--dark-neutral);">
                            Rp 2.500.000
                        </div>
                        
                        <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20pesan%20*Paket%20Business%20(Full%20Custom%20Website)*%20seharga%20Rp%202.500.000" target="_blank" class="btn btn-premium-outline w-100 py-3 mb-4" id="orderBusinessBtn">
                            <i class="bi bi-whatsapp me-2"></i>Pesan Sekarang
                        </a>
                        
                        <hr class="my-4 border-pink-light">
                        
                        <ul class="price-features">
                            <li><i class="bi bi-check-circle-fill"></i> Full Custom Layout</li>
                            <li><i class="bi bi-check-circle-fill"></i> Free Domain & Hosting</li>
                            <li><i class="bi bi-check-circle-fill"></i> Fitur Sesuai Kebutuhan</li>
                            <li><i class="bi bi-check-circle-fill"></i> Optimasi SEO Lanjutan</li>
                            <li><i class="bi bi-check-circle-fill"></i> Prioritas Support 24/7</li>
                            <li><i class="bi bi-check-circle-fill"></i> Revisi Tanpa Batas</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Katalog Section (Pilihan Jenis Website) -->
    <section class="py-5 bg-white" id="portofolio">
                    <span class="section-subtitle">Katalog Jasa</span>
                    <h2 class="section-title">Katalog Pilihan Jenis Website Premium</h2>
                    <p class="text-muted">Kami menawarkan 10 kategori website profesional yang siap disesuaikan sepenuhnya dengan model bisnis dan target audiens Anda.</p>
                </div>
            </div>
            
            <!-- Catalog Grid -->
            <div class="row g-4 mt-2">
                <!-- Catalog Item 1: Barbershop -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-duration="800" data-aos-delay="100">
                    <div class="catalog-card">
                        <div class="catalog-img-wrapper">
                            <img src="{{ asset('assets/images/portfolio-barbershop.png') }}" alt="Website Barbershop & Salon Premium Preview">
                        </div>
                        <div class="catalog-body">
                            <span class="catalog-badge">Lifestyle & Booking</span>
                            <h4 class="catalog-title">Barbershop & Salon</h4>
                            <p class="catalog-text">Dilengkapi sistem reservasi online terintegrasi, galeri hair-stylist, detail daftar harga, dan tautan langsung ke WhatsApp & Google Maps.</p>
                            <div class="catalog-footer">
                                <div class="catalog-price">
                                    Mulai Dari
                                    <span>Rp 350.000</span>
                                </div>
                                <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20membuat%20*Website%20Barbershop%20dan%20Salon*" target="_blank" class="catalog-btn" id="portfolioBtn1">
                                    Pesan <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Catalog Item 2: Coffee Shop -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-duration="800" data-aos-delay="200">
                    <div class="catalog-card">
                        <div class="catalog-img-wrapper">
                            <img src="{{ asset('assets/images/portfolio-coffeeshop.png') }}" alt="Website Coffee Shop & Cafe Aesthetic Preview">
                        </div>
                        <div class="catalog-body">
                            <span class="catalog-badge">Kuliner & Kafe</span>
                            <h4 class="catalog-title">Coffee Shop & Cafe</h4>
                            <p class="catalog-text">Profil menu aesthetic terintegrasi, foto interior, operational hours, maps, serta menu online/order meja instan untuk kenyamanan pengunjung.</p>
                            <div class="catalog-footer">
                                <div class="catalog-price">
                                    Mulai Dari
                                    <span>Rp 750.000</span>
                                </div>
                                <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20membuat%20*Website%20Coffee%20Shop%20dan%20Cafe*" target="_blank" class="catalog-btn" id="portfolioBtn2">
                                    Pesan <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Catalog Item 3: Toko Belanja Online -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-duration="800" data-aos-delay="300">
                    <div class="catalog-card">
                        <div class="catalog-img-wrapper">
                            <img src="{{ asset('assets/images/portfolio-1.png') }}" alt="Website Toko Belanja Online E-Commerce Preview">
                        </div>
                        <div class="catalog-body">
                            <span class="catalog-badge">E-Commerce Store</span>
                            <h4 class="catalog-title">Toko Belanja Online</h4>
                            <p class="catalog-text">Katalog produk lengkap, sistem keranjang belanja digital, otomatisasi ongkir ekspedisi lokal, dan checkout pembayaran instan.</p>
                            <div class="catalog-footer">
                                <div class="catalog-price">
                                    Mulai Dari
                                    <span>Rp 1.500.000</span>
                                </div>
                                <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20membuat%20*Website%20Toko%20Belanja%20Online%20(E-Commerce)*" target="_blank" class="catalog-btn" id="portfolioBtn3">
                                    Pesan <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Catalog Item 4: Fotografi & Portofolio Kreatif -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-duration="800" data-aos-delay="100">
                    <div class="catalog-card">
                        <div class="catalog-img-wrapper">
                            <img src="{{ asset('assets/images/portfolio-photography.png') }}" alt="Website Fotografi & Portofolio Kreatif Preview">
                        </div>
                        <div class="catalog-body">
                            <span class="catalog-badge">Personal & Creative</span>
                            <h4 class="catalog-title">Portofolio & Fotografi</h4>
                            <p class="catalog-text">Galeri karya resolusi tinggi, profil fotografer/kreator, testimonial klien, paket jasa, dan formulir kontak kolaborasi proyek kreatif.</p>
                            <div class="catalog-footer">
                                <div class="catalog-price">
                                    Mulai Dari
                                    <span>Rp 350.000</span>
                                </div>
                                <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20membuat%20*Website%20Portofolio%20Fotografi*" target="_blank" class="catalog-btn" id="portfolioBtn5">
                                    Pesan <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Catalog Item 5: Company Profile UMKM -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-duration="800" data-aos-delay="200">
                    <div class="catalog-card">
                        <div class="catalog-img-wrapper">
                            <img src="{{ asset('assets/images/portfolio-umkm.png') }}" alt="Website Company Profile UMKM Preview">
                        </div>
                        <div class="catalog-body">
                            <span class="catalog-badge">Corporate & UMKM</span>
                            <h4 class="catalog-title">Company Profile UMKM</h4>
                            <p class="catalog-text">Profil visi misi usaha, katalog layanan/produk, legalitas, kontak resmi, peta maps, serta blog artikel update informasi bisnis Anda.</p>
                            <div class="catalog-footer">
                                <div class="catalog-price">
                                    Mulai Dari
                                    <span>Rp 750.000</span>
                                </div>
                                <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20membuat%20*Website%20Company%20Profile%20UMKM*" target="_blank" class="catalog-btn" id="portfolioBtn6">
                                    Pesan <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Catalog Item 6: Landing Page Properti -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-duration="800" data-aos-delay="300">
                    <div class="catalog-card">
                        <div class="catalog-img-wrapper">
                            <img src="{{ asset('assets/images/portfolio-property.png') }}" alt="Website Landing Page Properti Preview">
                        </div>
                        <div class="catalog-body">
                            <span class="catalog-badge">Property Agency</span>
                            <h4 class="catalog-title">Landing Page Properti</h4>
                            <p class="catalog-text">Daftar listing rumah/tanah, galeri foto & video properti, kalkulator KPR, peta lokasi, dan tombol chat WhatsApp agen marketing.</p>
                            <div class="catalog-footer">
                                <div class="catalog-price">
                                    Mulai Dari
                                    <span>Rp 750.000</span>
                                </div>
                                <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20membuat%20*Website%20Landing%20Page%20Properti*" target="_blank" class="catalog-btn" id="portfolioBtn7">
                                    Pesan <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Catalog Item 7: Rental Mobil & Travel -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-duration="800" data-aos-delay="100">
                    <div class="catalog-card">
                        <div class="catalog-img-wrapper">
                            <img src="{{ asset('assets/images/portfolio-rental.png') }}" alt="Website Rental Mobil & Travel Preview">
                        </div>
                        <div class="catalog-body">
                            <span class="catalog-badge">Transportation</span>
                            <h4 class="catalog-title">Rental Mobil & Travel</h4>
                            <p class="catalog-text">Daftar armada kendaraan, formulir booking tanggal & durasi sewa, pricelist sewa driver/lepas kunci, dan integrasi WhatsApp driver.</p>
                            <div class="catalog-footer">
                                <div class="catalog-price">
                                    Mulai Dari
                                    <span>Rp 1.500.000</span>
                                </div>
                                <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20membuat%20*Website%20Rental%20Mobil%20dan%20Travel*" target="_blank" class="catalog-btn" id="portfolioBtn8">
                                    Pesan <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Catalog Item 8: Website Sekolah -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-duration="800" data-aos-delay="200">
                    <div class="catalog-card">
                        <div class="catalog-img-wrapper">
                            <img src="{{ asset('assets/images/portfolio-2.png') }}" alt="Website Sekolah & Education Preview">
                        </div>
                        <div class="catalog-body">
                            <span class="catalog-badge">Education Portal</span>
                            <h4 class="catalog-title">Website Sekolah & Kursus</h4>
                            <p class="catalog-text">Profil instansi, pengumuman berkala, pendaftaran siswa baru online (PPDB), modul materi pelajaran, dan galeri kegiatan prestasi.</p>
                            <div class="catalog-footer">
                                <div class="catalog-price">
                                    Mulai Dari
                                    <span>Rp 1.500.000</span>
                                </div>
                                <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20membuat%20*Website%20Sekolah%20dan%20Kursus*" target="_blank" class="catalog-btn" id="portfolioBtn9">
                                    Pesan <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Catalog Item 9: Klinik & Kesehatan -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-duration="800" data-aos-delay="300">
                    <div class="catalog-card">
                        <div class="catalog-img-wrapper">
                            <img src="{{ asset('assets/images/portfolio-4.png') }}" alt="Website Klinik & Kesehatan Preview">
                        </div>
                        <div class="catalog-body">
                            <span class="catalog-badge">Medical Healthcare</span>
                            <h4 class="catalog-title">Klinik & Janji Temu Medis</h4>
                            <p class="catalog-text">Profil klinik, daftar dokter spesialis, jadwal praktek harian interaktif, form booking janji temu pasien, dan artikel blog kesehatan.</p>
                            <div class="catalog-footer">
                                <div class="catalog-price">
                                    Mulai Dari
                                    <span>Rp 1.500.000</span>
                                </div>
                                <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20membuat%20*Website%20Klinik%20dan%20Janji%20Temu*" target="_blank" class="catalog-btn" id="portfolioBtn10">
                                    Pesan <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Catalog Item 10: Custom Website -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-duration="800" data-aos-delay="100">
                    <div class="catalog-card">
                        <div class="catalog-img-wrapper">
                            <img src="{{ asset('assets/images/portfolio-3.png') }}" alt="Website Aplikasi Custom Khusus Preview">
                        </div>
                        <div class="catalog-body">
                            <span class="catalog-badge">SaaS & Custom App</span>
                            <h4 class="catalog-title">Website Aplikasi Custom</h4>
                            <p class="catalog-text">Sistem kustomisasi penuh mencakup platform booking hotel/tiket, direktori keanggotaan, dasbor admin terintegrasi, dan integrasi API.</p>
                            <div class="catalog-footer">
                                <div class="catalog-price">
                                    Mulai Dari
                                    <span>Rp 2.500.000</span>
                                </div>
                                <a href="https://wa.me/6288989200133?text=Halo%20Admin,%20saya%20tertarik%20membuat%20*Website%20Aplikasi%20Custom%20Khusus*" target="_blank" class="catalog-btn" id="portfolioBtn4">
                                    Pesan <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Page Section -->
    <section class="py-5 bg-soft-pink" id="kontak">
        <div class="container py-5">
            <!-- Section Title -->
            <div class="row justify-content-center text-center mb-5">
                <div class="col-lg-7" data-aos="fade-up" data-aos-duration="800">
                    <span class="section-subtitle">Hubungi Kami</span>
                    <h2 class="section-title">Mari Wujudkan Website Impian Anda Bersama Kami</h2>
                    <p class="text-muted">Siap berkonsultasi? Kirim detail project Anda melalui formulir di bawah ini atau chat langsung bersama Admin kami.</p>
                </div>
            </div>
            
            <div class="row g-4 align-items-stretch mt-2">
                <!-- Left Column: Admin Info -->
                <div class="col-lg-5" data-aos="fade-right" data-aos-duration="900">
                    <div class="contact-info-wrapper shadow-sm">
                        <h3 class="fw-bold mb-3 text-pink-magenta">Haliza UMKM Web HQ</h3>
                        <p class="text-muted small">Agensi digital spesialis pembuat website modern berbasis Bootstrap 5 dengan cita rasa desain kelas tinggi dan performa premium.</p>
                        
                        <ul class="contact-info-list">
                            <li>
                                <div class="contact-icon"><i class="bi bi-whatsapp"></i></div>
                                <div class="contact-text">
                                    <h5>WhatsApp Admin</h5>
                                    <p>+62 889-8920-0133</p>
                                </div>
                            </li>
                            <li>
                                <div class="contact-icon"><i class="bi bi-envelope-open-fill"></i></div>
                                <div class="contact-text">
                                    <h5>Email Resmi</h5>
                                    <p>halizaumkmweb@gmail.com</p>
                                </div>
                            </li>
                            <li>
                                <div class="contact-icon"><i class="bi bi-geo-alt-fill"></i></div>
                                <div class="contact-text">
                                    <h5>Alamat Kantor</h5>
                                    <p>Jl. Sungkono No.188 Bangil, Pasuruan 6753 Jawa Timur Indonesia</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                
                <!-- Right Column: Form Contact -->
                <div class="col-lg-7" data-aos="fade-left" data-aos-duration="900">
                    <div class="form-card">
                        <h4 class="fw-bold mb-4">Konsultasikan Detail Kebutuhan Anda</h4>
                        
                        <!-- Response Notification Alert -->
                        <div id="formResponse" style="display: none;"></div>
                        
                        <form id="premiumContactForm" class="row g-3">
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="inputName" placeholder="Nama Lengkap" required>
                                    <label for="inputName">Nama Lengkap*</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="email" class="form-control" id="inputEmail" placeholder="nama@email.com" required>
                                    <label for="inputEmail">Email Aktif*</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="tel" class="form-control" id="inputPhone" placeholder="08123456789">
                                    <label for="inputPhone">Nomor WhatsApp</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <select class="form-select" id="selectService">
                                        <option value="Paket Basic">Paket Basic (Rp 350.000)</option>
                                        <option value="Paket Standard">Paket Standard (Rp 750.000)</option>
                                        <option value="Paket Premium" selected>Paket Premium (Rp 1.500.000)</option>
                                        <option value="Paket Business">Paket Business (Rp 2.500.000)</option>
                                    </select>
                                    <label for="selectService">Pilihan Layanan</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea class="form-control" placeholder="Tulis pesan Anda di sini" id="textareaMessage" style="height: 140px" required></textarea>
                                    <label for="textareaMessage">Detail Rencana Project Website Anda*</label>
                                </div>
                            </div>
                            <div class="col-12 mt-4 text-end">
                                <button type="submit" class="btn btn-premium-pink btn-lg px-5 py-3" id="submitFormBtn">
                                    Kirim Rencana Project <i class="bi bi-send-fill ms-2"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Floating WhatsApp Button -->
    <a href="https://wa.me/6288989200133?text=Halo%20Admin%20Haliza%20UMKM%20Web,%20saya%20ingin%20konsultasi%20mengenai%20jasa%20pembuatan%20website..." target="_blank" class="floating-whatsapp" id="floatingWhatsappBtn" aria-label="Chat WhatsApp Admin">
        <i class="bi bi-whatsapp"></i>
    </a>

    <!-- Footer Section -->
    <footer class="premium-footer">
        <div class="container">
            <div class="row g-4">
                <!-- Branding column -->
                <div class="col-lg-5">
                    <div class="footer-brand"><i class="bi bi-hexagon-fill text-pink-primary me-2"></i>Haliza UMKM <span>Web</span></div>
                    <p class="text-muted small mb-4" style="max-width: 400px; color: #B59FA5 !important;">
                        Hadir sebagai pionir agensi digital pembuat website modern berestetika tinggi. Kami mendedikasikan keahlian kami pada detail layout, kecepatan memuat, dan tingkat konversi yang tinggi untuk kesuksesan digital brand Anda.
                    </p>

                </div>
                
                <!-- Quick links column -->
                <div class="col-md-6 col-lg-3 offset-lg-1">
                    <h5 class="fw-bold text-white mb-4">Navigasi Link</h5>
                    <ul class="footer-links">
                        <li><a href="#hero">Home</a></li>
                        <li><a href="#keunggulan">Keunggulan Layanan</a></li>
                        <li><a href="#paket">Pilihan Paket</a></li>
                        <li><a href="#portofolio">Katalog Layanan</a></li>
                        <li><a href="#kontak">Hubungi Kontak</a></li>
                    </ul>
                </div>
                
                <!-- Information column -->
                <div class="col-md-6 col-lg-3">
                    <h5 class="fw-bold text-white mb-4">Informasi Agensi</h5>
                    <div class="footer-contact-item">
                        <i class="bi bi-geo-alt-fill"></i>
                        <span>Jl. Sungkono No.188 Bangil, Pasuruan 6753 Jawa Timur Indonesia</span>
                    </div>
                    <div class="footer-contact-item">
                        <i class="bi bi-telephone-fill"></i>
                        <span>+62 889-8920-0133</span>
                    </div>
                    <div class="footer-contact-item">
                        <i class="bi bi-envelope-fill"></i>
                        <span>halizaumkmweb@gmail.com</span>
                    </div>
                </div>
            </div>
            
            <div class="footer-divider"></div>
            
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start">
                        <p class="small mb-0" style="color: #8C757B !important;">
                            &copy; {{ date('Y') }} Haliza UMKM Web. All rights reserved.
                        </p>
                    </div>
                <div class="col-md-6 text-center text-md-end mt-2 mt-md-0">
                    <p class="small mb-0" style="color: #8C757B !important;">
                        Dibuat dengan <i class="bi bi-heart-fill text-pink-primary mx-1"></i> untuk Kredibilitas Digital Premium.
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Animate On Scroll (AOS) JS -->
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        // Initialize AOS animations
        AOS.init({
            once: true, // animation happens only once while scrolling down
            mirror: false // elements don't animate out when scrolling past them
        });
    </script>
    
    <!-- Custom Main JS -->
    <script src="{{ asset('js/main.js') }}"></script>
</body>
</html>
