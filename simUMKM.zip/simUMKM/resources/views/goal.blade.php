<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Goal Page</title>
    <style>
        body {font-family: Arial, sans-serif; background:#f4f7f9; color:#333; display:flex; align-items:center; justify-content:center; height:100vh; margin:0;}
        .card {background:#fff; padding:2rem 3rem; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,.1); text-align:center;}
        h1 {margin-top:0;}
    </style>
</head>
<body>
    <div class="card">
        <h1>Goal Page</h1>
        <p>Halaman ini berhasil diakses melalui <code>/goal</code>.</p>
    </div>
</body>
</html>
